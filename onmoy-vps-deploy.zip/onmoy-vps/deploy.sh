#!/usr/bin/env bash
# Развёртывание сайта-карты «Он мой» на VPS: статический сайт + Caddy с автоматическим HTTPS.
#   sudo bash deploy.sh           — проверить сервер и запустить сайт (повторный запуск безопасен)
#   sudo bash deploy.sh --check   — только проверки, ничего не устанавливать и не запускать
#
# Сайт публикуется только на том IP-адресе сервера, на который указывает домен: другие адреса сервера
# (и сервисы, которые слушают порты 80/443 на них) не затрагиваются. Задать адрес вручную:
#   sudo BIND_IP=203.0.113.10 bash deploy.sh
set -Eeuo pipefail

DOMAIN='xn--i1afcdc.xn--p1ai'
DISPLAY_DOMAIN='онмой.рф'
CONTAINER='onmoy-web'
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
CHECK_ONLY=0
[[ "${1:-}" == "--check" ]] && CHECK_ONLY=1

say()  { printf '%s\n' "$*"; }
fail() { printf '\nОшибка: %s\n' "$*" >&2; exit 1; }

[[ "${EUID}" -eq 0 ]] || fail 'запустите скрипт с sudo: sudo bash deploy.sh'
[[ -f "${SCRIPT_DIR}/docker-compose.yml" && -f "${SCRIPT_DIR}/Caddyfile" && -f "${SCRIPT_DIR}/site/index.html" ]] \
  || fail 'распакуйте ZIP целиком и запускайте скрипт из папки onmoy-vps'

[[ -r /etc/os-release ]] || fail 'не удалось определить Linux-дистрибутив'
# shellcheck disable=SC1091
source /etc/os-release
case "${ID:-}" in
  ubuntu|debian) ;;
  *) fail "поддерживаются Ubuntu и Debian; обнаружен ${PRETTY_NAME:-неизвестный дистрибутив}" ;;
esac

# ── 1. Домен должен указывать на ЭТОТ сервер, иначе HTTPS-сертификат не выдадут.
say "Проверяю DNS домена ${DISPLAY_DOMAIN}…"
domain_ips="$(getent ahostsv4 "${DOMAIN}" 2>/dev/null | awk '{print $1}' | sort -u | tr '\n' ' ' || true)"
[[ -n "${domain_ips// /}" ]] || fail "домен ${DISPLAY_DOMAIN} пока не разрешается в IPv4-адрес. Создайте A-запись на IP этого VPS, подождите обновления DNS (до нескольких часов) и запустите команду снова."

server_ips="$(ip -4 -o addr show scope global 2>/dev/null | awk '{print $4}' | cut -d/ -f1 | tr '\n' ' ' || true)"
if command -v curl >/dev/null 2>&1; then
  public_ip="$(curl -4fsS --max-time 8 https://api.ipify.org 2>/dev/null || curl -4fsS --max-time 8 https://ifconfig.me 2>/dev/null || true)"
  server_ips="${server_ips} ${public_ip}"
fi

dns_ok=0
for d in ${domain_ips}; do
  for s in ${server_ips}; do [[ "${d}" == "${s}" ]] && dns_ok=1; done
done
if [[ "${dns_ok}" -ne 1 && "${SKIP_DNS_CHECK:-0}" != "1" ]]; then
  fail "домен ${DISPLAY_DOMAIN} указывает на ${domain_ips}, а адреса этого сервера: ${server_ips:-не определены}.
Исправьте A-запись домена на IP этого VPS (и удалите AAAA-запись, если у VPS нет IPv6), подождите обновления DNS
и запустите команду снова. Если вы уверены, что DNS настроен верно (например, сервер за NAT):
    sudo SKIP_DNS_CHECK=1 bash deploy.sh"
fi
say "  домен указывает на: ${domain_ips}"

# ── 2. На каком адресе сервера публиковать сайт: на том, куда указывает домен.
#    Если такого адреса на сетевых интерфейсах нет (сервер за NAT) — на всех адресах, как обычно.
local_ips="$(ip -4 -o addr show 2>/dev/null | awk '{print $4}' | cut -d/ -f1 | tr '\n' ' ' || true)"
bind_ip="${BIND_IP:-}"
if [[ -n "${bind_ip}" ]]; then
  found=0
  for s in ${local_ips}; do [[ "${bind_ip}" == "${s}" ]] && found=1; done
  [[ "${found}" -eq 1 ]] || fail "BIND_IP=${bind_ip}: такого адреса нет на этом сервере. Адреса сервера: ${local_ips}"
else
  for d in ${domain_ips}; do
    for s in ${local_ips}; do [[ "${d}" == "${s}" ]] && bind_ip="${d}"; done
  done
fi
if [[ -n "${bind_ip}" ]]; then
  say "  сайт займёт порты 80 и 443 только на адресе ${bind_ip}"
else
  say '  адрес домена не найден на сетевых интерфейсах (сервер за NAT?) — сайт займёт порты 80 и 443 на всех адресах'
fi

# ── 3. Порты 80 и 443 на этом адресе должны быть свободны (или заняты нашим же контейнером
#    при повторном запуске). Сервисы, которые слушают те же порты на ДРУГИХ адресах, не мешают.
ours_running=0
if command -v docker >/dev/null 2>&1 && [[ "$(docker inspect -f '{{.State.Running}}' "${CONTAINER}" 2>/dev/null || true)" == "true" ]]; then
  ours_running=1
fi

# Занят ли порт $2 (протокол $1: t — TCP, u — UDP) на нашем адресе: мешают слушатели на самом адресе
# и на «всех адресах» (0.0.0.0, *, [::]); если сайт сам занимает все адреса — любой IPv4-слушатель.
port_busy() {
  local addr
  while read -r addr; do
    addr="${addr%:*}"
    case "${addr}" in
      '0.0.0.0'|'*'|'[::]') return 0 ;;
      '['*) ;;                                   # отдельный IPv6-адрес — не мешает
      *) [[ -z "${bind_ip}" || "${addr}" == "${bind_ip}" ]] && return 0 ;;
    esac
  done < <(ss -H -l -n "-${1}" "sport = :${2}" 2>/dev/null | awk '{print $(NF-1)}')
  return 1
}

if [[ "${ours_running}" -ne 1 && "${SKIP_PORT_CHECK:-0}" != "1" ]] && command -v ss >/dev/null 2>&1; then
  where="${bind_ip:-всех адресах сервера}"
  for port in 80 443; do
    if port_busy t "${port}"; then
      fail "порт ${port} на ${where} уже занят другой программой (например, nginx или apache).
Посмотреть, кто занимает порт: sudo ss -ltnp 'sport = :${port}'
Сайту нужен свободный порт ${port} именно на том адресе, куда указывает домен. Если программа слушает
все адреса сразу (0.0.0.0 или *), перенастройте её на конкретный адрес или остановите.
Если вы уверены, что порт свободен: sudo SKIP_PORT_CHECK=1 bash deploy.sh"
    fi
  done
  if port_busy u 443; then
    fail "порт 443/UDP на ${where} уже занят другой программой.
Посмотреть, кто занимает порт: sudo ss -lunp 'sport = :443'
Если вы уверены, что порт свободен: sudo SKIP_PORT_CHECK=1 bash deploy.sh"
  fi
fi
say "  порты 80 и 443 на ${bind_ip:-всех адресах} свободны"

if [[ "${CHECK_ONLY}" -eq 1 ]]; then
  say ''
  say 'Проверки пройдены. Для установки запустите: sudo bash deploy.sh'
  exit 0
fi

# ── 4. Права на чтение: контейнер работает без лишних привилегий и читает только общедоступные файлы.
chmod a+rx "${SCRIPT_DIR}"
chmod -R a+rX "${SCRIPT_DIR}/site"
chmod a+r "${SCRIPT_DIR}/Caddyfile" "${SCRIPT_DIR}/docker-compose.yml"

# ── 5. Файрвол ufw, если включён: открыть веб-порты.
if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -q '^Status: active'; then
  say 'Открываю порты 80 и 443 в файрволе ufw…'
  ufw allow 80/tcp >/dev/null
  ufw allow 443/tcp >/dev/null
  ufw allow 443/udp >/dev/null
fi

# ── 6. Docker.
if ! command -v docker >/dev/null 2>&1 || ! docker compose version >/dev/null 2>&1; then
  say 'Устанавливаю Docker Engine и Docker Compose…'
  export DEBIAN_FRONTEND=noninteractive
  apt-get update
  apt-get install -y ca-certificates curl
  curl -fsSL https://get.docker.com | sh
fi
command -v curl >/dev/null 2>&1 || { apt-get update; apt-get install -y ca-certificates curl; }

# ── 7. Запуск. Адрес публикации запоминается в .env — его читают и последующие команды docker compose.
printf 'ONMOY_BIND=%s\n' "${bind_ip:+${bind_ip}:}" > "${SCRIPT_DIR}/.env"
chmod a+r "${SCRIPT_DIR}/.env"
compose() { docker compose -f "${SCRIPT_DIR}/docker-compose.yml" --project-directory "${SCRIPT_DIR}" "$@"; }
compose config -q
say "Запускаю сайт и HTTPS для https://${DISPLAY_DOMAIN}/ …"
compose up -d
# Повторный запуск после обновления файлов: перечитать настройки без остановки сайта.
[[ "${ours_running}" -eq 1 ]] && compose restart web >/dev/null

# ── 8. Проверка: ждём сертификат (обычно меньше минуты) и открываем сайт.
say 'Жду выпуска HTTPS-сертификата и проверяю сайт…'
ok=0
for _ in $(seq 1 30); do
  if curl -fsS --max-time 8 --resolve "${DOMAIN}:443:${bind_ip:-127.0.0.1}" "https://${DOMAIN}/" 2>/dev/null | grep -q '<div class="splash">'; then
    ok=1
    break
  fi
  sleep 4
done

say ''
if [[ "${ok}" -eq 1 ]]; then
  say 'Готово: сайт работает по HTTPS и будет запускаться сам после перезагрузки VPS.'
else
  say 'Контейнер запущен, но сайт по HTTPS пока не отвечает. Чаще всего причина — DNS ещё не обновился'
  say 'или порты 80/443 закрыты в панели VPS. Подождите несколько минут и посмотрите журнал:'
  say "    cd ${SCRIPT_DIR} && sudo docker compose logs --tail 50 web"
fi
say "Сайт:     https://${DISPLAY_DOMAIN}/"
say "Политика: https://${DISPLAY_DOMAIN}/privacy.html"
say ''
say "Состояние: cd ${SCRIPT_DIR} && sudo docker compose ps"
[[ "${ok}" -eq 1 ]] || exit 1
