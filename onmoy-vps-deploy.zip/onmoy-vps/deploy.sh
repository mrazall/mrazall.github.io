#!/usr/bin/env bash
# Развёртывание сайта-карты «Он мой» на VPS: статический сайт + Caddy с автоматическим HTTPS.
#   sudo bash deploy.sh           — проверить сервер и запустить сайт (повторный запуск безопасен)
#   sudo bash deploy.sh --check   — только проверки, ничего не устанавливать и не запускать
set -Eeuo pipefail

DOMAIN='xn--i1afcdc.xn--p1ai'
DISPLAY_DOMAIN='онмой.рф'
CONTAINER='onmoy-web'
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
CHECK_ONLY=0
[[ "${1:-}" == "--check" ]] && CHECK_ONLY=1

say()  { printf '%s\n' "$*"; }
fail() { printf '\nОшибка: %s\n' "$*" >&2; exit 1; }

[[ "${EUID}" -eq 0 ]] || fail 'запустите скрипт с sudo: sudo bash deploy.sh'
[[ -f "${SCRIPT_DIR}/docker-compose.yml" && -f "${SCRIPT_DIR}/Caddyfile" && -f "${SCRIPT_DIR}/site/index.html" ]] \
  || fail 'распакуйте ZIP целиком и запускайте скрипт из папки onmoy-vps'

[[ -r /etc/os-release ]] || fail 'не удалось определить Linux-дистрибутив'
# shellcheck disable=SC1091
source /etc/os-release
case "${ID:-}" in
  ubuntu|debian) ;;
  *) fail "поддерживаются Ubuntu и Debian; обнаружен ${PRETTY_NAME:-неизвестный дистрибутив}" ;;
esac

# ── 1. Домен должен указывать на ЭТОТ сервер, иначе HTTPS-сертификат не выдадут.
say "Проверяю DNS домена ${DISPLAY_DOMAIN}…"
domain_ips="$(getent ahostsv4 "${DOMAIN}" 2>/dev/null | awk '{print $1}' | sort -u | tr '\n' ' ' || true)"
[[ -n "${domain_ips// /}" ]] || fail "домен ${DISPLAY_DOMAIN} пока не разрешается в IPv4-адрес. Создайте A-запись на IP этого VPS, подождите обновления DNS (до нескольких часов) и запустите команду снова."

server_ips="$(ip -4 -o addr show scope global 2>/dev/null | awk '{print $4}' | cut -d/ -f1 | tr '\n' ' ' || true)"
if command -v curl >/dev/null 2>&1; then
  public_ip="$(curl -4fsS --max-time 8 https://api.ipify.org 2>/dev/null || curl -4fsS --max-time 8 https://ifconfig.me 2>/dev/null || true)"
  server_ips="${server_ips} ${public_ip}"
fi

dns_ok=0
for d in ${domain_ips}; do
  for s in ${server_ips}; do [[ "${d}" == "${s}" ]] && dns_ok=1; done
done
if [[ "${dns_ok}" -ne 1 && "${SKIP_DNS_CHECK:-0}" != "1" ]]; then
  fail "домен ${DISPLAY_DOMAIN} указывает на ${domain_ips}, а адреса этого сервера: ${server_ips:-не определены}.
Исправьте A-запись домена на IP этого VPS (и удалите AAAA-запись, если у VPS нет IPv6), подождите обновления DNS
и запустите команду снова. Если вы уверены, что DNS настроен верно (например, сервер за NAT):
    sudo SKIP_DNS_CHECK=1 bash deploy.sh"
fi
say "  домен указывает на: ${domain_ips}"

# ── 2. Порты 80 и 443 должны быть свободны (или заняты нашим же контейнером при повторном запуске).
ours_running=0
if command -v docker >/dev/null 2>&1 && [[ "$(docker inspect -f '{{.State.Running}}' "${CONTAINER}" 2>/dev/null || true)" == "true" ]]; then
  ours_running=1
fi
if [[ "${ours_running}" -ne 1 ]] && command -v ss >/dev/null 2>&1; then
  for port in 80 443; do
    if ss -ltnH "sport = :${port}" 2>/dev/null | grep -q .; then
      fail "порт ${port} уже занят другой программой (например, nginx или apache). Остановите её и запустите команду снова.
Посмотреть, кто занимает порт: sudo ss -ltnp 'sport = :${port}'"
    fi
  done
fi
say '  порты 80 и 443 свободны'

if [[ "${CHECK_ONLY}" -eq 1 ]]; then
  say ''
  say 'Проверки пройдены. Для установки запустите: sudo bash deploy.sh'
  exit 0
fi

# ── 3. Права на чтение: контейнер работает без лишних привилегий и читает только общедоступные файлы.
chmod a+rx "${SCRIPT_DIR}"
chmod -R a+rX "${SCRIPT_DIR}/site"
chmod a+r "${SCRIPT_DIR}/Caddyfile" "${SCRIPT_DIR}/docker-compose.yml"

# ── 4. Файрвол ufw, если включён: открыть веб-порты.
if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -q '^Status: active'; then
  say 'Открываю порты 80 и 443 в файрволе ufw…'
  ufw allow 80/tcp >/dev/null
  ufw allow 443/tcp >/dev/null
  ufw allow 443/udp >/dev/null
fi

# ── 5. Docker.
if ! command -v docker >/dev/null 2>&1 || ! docker compose version >/dev/null 2>&1; then
  say 'Устанавливаю Docker Engine и Docker Compose…'
  export DEBIAN_FRONTEND=noninteractive
  apt-get update
  apt-get install -y ca-certificates curl
  curl -fsSL https://get.docker.com | sh
fi
command -v curl >/dev/null 2>&1 || { apt-get update; apt-get install -y ca-certificates curl; }

# ── 6. Запуск.
compose() { docker compose -f "${SCRIPT_DIR}/docker-compose.yml" --project-directory "${SCRIPT_DIR}" "$@"; }
compose config -q
say "Запускаю сайт и HTTPS для https://${DISPLAY_DOMAIN}/ …"
compose up -d
# Повторный запуск после обновления файлов: перечитать настройки без остановки сайта.
[[ "${ours_running}" -eq 1 ]] && compose restart web >/dev/null

# ── 7. Проверка: ждём сертификат (обычно меньше минуты) и открываем сайт.
say 'Жду выпуска HTTPS-сертификата и проверяю сайт…'
ok=0
for _ in $(seq 1 30); do
  if curl -fsS --max-time 8 --resolve "${DOMAIN}:443:127.0.0.1" "https://${DOMAIN}/" 2>/dev/null | grep -q '<div class="splash">'; then
    ok=1
    break
  fi
  sleep 4
done

say ''
if [[ "${ok}" -eq 1 ]]; then
  say 'Готово: сайт работает по HTTPS и будет запускаться сам после перезагрузки VPS.'
else
  say 'Контейнер запущен, но сайт по HTTPS пока не отвечает. Чаще всего причина — DNS ещё не обновился'
  say 'или порты 80/443 закрыты в панели VPS. Подождите несколько минут и посмотрите журнал:'
  say "    cd ${SCRIPT_DIR} && sudo docker compose logs --tail 50 web"
fi
say "Сайт:     https://${DISPLAY_DOMAIN}/"
say "Политика: https://${DISPLAY_DOMAIN}/privacy.html"
say ''
say "Состояние: cd ${SCRIPT_DIR} && sudo docker compose ps"
[[ "${ok}" -eq 1 ]] || exit 1
